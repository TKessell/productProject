create unique index PRODUCT_INDEX
    on PRODUCT (ID);

